
// enhanced script.js: project cards, mobile menu toggle, accordion behavior
document.addEventListener('DOMContentLoaded', function(){
  // project cards generation (if grid exists)
  try { if (typeof generateProjectCards === 'function') generateProjectCards(); } catch(e) {}

  // mobile menu toggle
  const mobileToggle = document.querySelector('.mobile-toggle');
  const navbar = document.querySelector('.navbar');
  if (mobileToggle && navbar) {
    mobileToggle.addEventListener('click', function(){
      navbar.classList.toggle('active');
      const icon = mobileToggle.querySelector('i');
      if (icon) { icon.classList.toggle('fa-bars'); icon.classList.toggle('fa-times'); }
    });
  }

  // accordion behavior
  document.querySelectorAll('.accordion-header').forEach(header => {
    header.addEventListener('click', () => {
      const accordion = header.parentElement;
      // close others
      document.querySelectorAll('.accordion').forEach(a=>{ if(a!==accordion) a.classList.remove('active'); });
      accordion.classList.toggle('active');
    });
  });
});
